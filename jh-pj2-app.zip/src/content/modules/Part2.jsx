// jh_PJ2 메인페이지 Part2 컴포넌트

// Part2 css 불러오기
import "../css/part2.css";

export function Part2() {
  return (
    <>
      <div className="pt2 cbx2-1">
        <div className="pt2 tbox">
          <p>따스한 온기를 전달하여</p>
          <p>
            고요한 무드로 이끌어주는
            <br />
            바디 오일
          </p>
          <p>서렌 바디오일 라벤터 & 마조람</p>
        </div>
      </div>
      <div className="pt2 cbx2-2 bgi"></div>
    </>
  );
} /////////// Part2 컴포넌트 ///////////
