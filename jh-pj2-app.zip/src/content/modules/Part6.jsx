// jh_PJ2 메인페이지 Part6 컴포넌트 - 리뷰

// Part6 css 불러오기
import { useEffect } from "react";
import "../css/part6.css";

import $ from "jquery";
import "jquery-ui-dist/jquery-ui";

//// Part6 컴포넌트 /////////////
export function Part6() {
  return(
    <>
    <h1>REVIEW</h1>
    
    </>
  )
} /////////// Part6 컴포넌트 ///////////
