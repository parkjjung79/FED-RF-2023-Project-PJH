// jh_PJ2 메인페이지 Review 컴포넌트

// Review css 불러오기
import "../css/review.css";

export function Review() {
  return (
    <>
      <React.Fragment>
        
      </React.Fragment>
    </>
  );
} /////////// Review 컴포넌트 ///////////
