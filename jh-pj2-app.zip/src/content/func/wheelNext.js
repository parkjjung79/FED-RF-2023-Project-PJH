// 메인 Part4 휠기능으로 한줄씩 이동함수 - wheelNext.js

import $ from "jquery";
window.jQuery = $;
require("jquery-ui-dist/jquery-ui");
require("jquery-ui-touch-punch/jquery.ui.touch-punch");

export function wheelNext() {
  // 이벤트 종류 : wheel
  // 이벤트 대상 : .contbox p

  // .contbox p
  let conp= $(".contbox p");
  
    // console.log(conp);

  // 휠 기능넣기
  conp.wheel

} /////////// wheelNext 함수 //////////////
