// jh_PJ2 ShopContents 영역 공통 컴포넌트

import { createContext } from "react";

// jh PJ - Context API 
export const shpCon = createContext();