// jh_PJ2 서브페이지 소개 컴포넌트

export function Introduce(){
    return(
        <>
            <h1>서브 페이지 입니다.</h1>
        </>
    )
}